const player1 = document.querySelector(".img1");
const player2 = document.querySelector(".img2");
const message = document.querySelector("h1");

let randomInt1 = Math.floor(Math.random() * (6 - 1 + 1)) + 1;
let randomInt2 = Math.floor(Math.random() * (6 - 1 + 1)) + 1;

if (randomInt1 < randomInt2) {
  message.innerText = "Player 2 wins";
} else if (randomInt1 > randomInt2) {
  message.innerText = "Player 1 wins";
} else message.innerText = "Draw";

player1.setAttribute("src", `images/dice${randomInt1}.png`);
player2.setAttribute("src", `images/dice${randomInt2}.png`);
