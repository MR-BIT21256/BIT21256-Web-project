-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2025 at 02:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(0, 'admin', 'admin123', 'admin'),
(0, 'asdf123', '$2y$10$jbrREiPPAVI5jQmw9luw4ePEHK5pSv94a8ZCZi73IViy54DUv1Rpy', 'user'),
(0, 'mr', '$2y$10$4FzVeKwyp308zhuaBFbd3ug.GCmNOQsGHejpcO24hBop31ODqfPJG', 'user'),
(0, 'asdf123', '$2y$10$CnbQWbiNhgHRpCIPUZLStuYbo2XxgAoC.vy4mIYlsw7hY6YyvFgfq', 'user'),
(0, 'asdf123', '$2y$10$xDsHwAOsnwVNm6cPBi6js.gXedJ.wEnfTDSaf0wdyhjDihdAN1SQi', 'user'),
(0, 'admin', '$2y$10$09felExk2KaIVTwOQMIOvuDLM.l12XGndHnnXXxVH2OdDzDmRe4re', 'user'),
(0, 'qwe', '$2y$10$0nSpsy.zZYn.t9oix/0oLu4KhgXPFNiXDgeUh2AgsD5YicZKc/Ul6', 'user'),
(0, 'qwe', '$2y$10$vT5KRcsj3r8RO6cRsokAUeFQqI9H85ci5K05uPNLJ7nblurophl2K', 'user');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
