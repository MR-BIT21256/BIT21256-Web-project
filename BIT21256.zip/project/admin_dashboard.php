<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>Admin Dashboard</header>

<h2>Manage Products</h2>

<a href="add_product.php" class="btn">Add New Product</a>

<table border="1">
    <tr>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Actions</th>
    </tr>

    <?php
    $query = "SELECT * FROM product";
    $result = mysqli_query($conn, $query);

    while ($product = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $product['name'] . "</td>";
        echo "<td>" . $product['description'] . "</td>";
        echo "<td>$" . $product['price'] . "</td>";
        echo "<td>
                <a href='edit_product.php?id=" . $product['id'] . "' class='btn'>Edit</a>
                <a href='delete_product.php?id=" . $product['id'] . "' class='btn delete-btn' onclick='return confirm(\"Are you sure?\")'>Delete</a>              
                </td>";
        echo "</tr>";
    }
    ?>
</table>

<a href="logout.php" class="btn logout-btn">Logout</a>

</body>
</html>
