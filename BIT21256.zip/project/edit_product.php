<?php
session_start();
include 'connect.php';

// Ensure the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: admin_login.php");
    exit();
}

// Fetch the product details based on the ID in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM product WHERE id='$id'");
    if ($result) {
        $product = mysqli_fetch_assoc($result);
    } else {
        die("Product not found.");
    }
}

// If the form is submitted, update the product details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    
    // Update the product record in the database
    $updateQuery = "UPDATE product SET name='$name', description='$description', price='$price' WHERE id='$id'";
    if (mysqli_query($conn, $updateQuery)) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Error updating product: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="form-container">
        <h2>Edit Product</h2>
    <form method="POST">
        <!-- Form fields to edit the product -->
        <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>

        <input type="text" name="description" id="description" value="<?php echo htmlspecialchars($product['description']); ?>" required>

        <input type="number" name="price" id="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>

        <button type="submit">Update Product</button>
    </form>
</div>
</body>
</html>
