<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to My shop</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            font-weight: bold;
            color: #333;
        }
        p {
            color: #666;
        }
        .btn-custom {
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to MY Shop</h1>
        <p>This is a simple website to demonstrate login and signup functionality.</p>
        <a href="login.php" class="btn btn-primary btn-custom">Login</a>
        <a href="signup.php" class="btn btn-secondary btn-custom">Sign Up</a>
        <a href="admin_login.php" class="btn btn-warning btn-custom">Admin Panel</a>
    </div>
</body>
</html>
