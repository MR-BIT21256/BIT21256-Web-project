<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Products</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>Welcome, <?php echo $_SESSION['username']; ?>!</header>

<h2>Available Products</h2>

<div class="products-container">
    <?php
    $query = "SELECT * FROM product";
    $result = mysqli_query($conn, $query);

    while ($product = mysqli_fetch_assoc($result)) {
        echo "<div class='product-card'>";
        echo "<h3>" . $product['name'] . "</h3>";
        echo "<p>" . $product['description'] . "</p>";
        echo "<p><strong>Price:</strong> $" . $product['price'] . "</p>";
        echo "</div>";
    }
    ?>
</div>

<a href="logout.php" class="btn logout-btn">Logout</a>

</body>
</html>
